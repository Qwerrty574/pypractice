import math


def f(n, m):
    p1 = 0
    p2 = 0
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            p1 += i ** 7 - i ** 4 / 85
        p2 += i ** 2 + i
    return 64 * p1 + p2


print('f({},{}) = {:.2e}'.format(35, 80, f(35, 80)))
print('f({},{}) = {:.2e}'.format(68, 87, f(68, 87)))
